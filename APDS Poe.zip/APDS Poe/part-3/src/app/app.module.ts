import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    
  ],
  imports: [
    HttpClientModule,
    AppComponent,
    FormsModule
  ],
  providers: [],
  bootstrap: []
})
export class AppModule { }

