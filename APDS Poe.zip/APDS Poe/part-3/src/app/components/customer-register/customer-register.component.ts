import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-register',
    templateUrl: './customer-register.component.html',
    styleUrls: ['./customer-register.component.css']
})
export class RegisterComponent {
    registrationData = {
        firstName: '',
        lastName: '',
        emailAddress: '',
        username: '',
        password: '',
        confirmPassword: '',
        accountNumber: '',
        idNumber: ''
    };

    constructor(private http: HttpClient) {}

    onSubmit() {
        if (this.registrationData.password !== this.registrationData.confirmPassword) {
            alert("Passwords do not match!");
            return;
        }

        // Send the data to the backend for hashing and saving
        this.http.post('/api/register', this.registrationData).subscribe({
            next: () => alert("Registration successful!"),
            error: err => console.error(err)
        });
    }
}
