const express = require('express');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const Customer = require('./models/customer.model');
const ExpressBrute = require('express-brute');

const router = express.Router();

// Brute-force protection
const bruteStore = new ExpressBrute.MemoryStore();
const bruteForce = new ExpressBrute(bruteStore);

// Regex patterns for input validation
const regexPatterns = {
  name: /^[a-zA-Z]{1,30}$/,
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  username: /^[a-zA-Z0-9]{5,15}$/,
  password: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/,
  accountNumber: /^\d{10,12}$/,
  idNumber: /^\d{8,12}$/
};

// Registration Route
router.post('/', bruteForce.prevent, async (req, res) => {
  try {
    const { firstName, lastName, emailAddress, username, password, accountNumber, idNumber } = req.body;

    // Validate inputs
    if (!regexPatterns.name.test(firstName) || !regexPatterns.name.test(lastName)) {
      return res.status(400).json({ error: 'Invalid name format' });
    }
    if (!regexPatterns.email.test(emailAddress) || !regexPatterns.username.test(username) ||
        !regexPatterns.password.test(password) || !regexPatterns.accountNumber.test(accountNumber) ||
        !regexPatterns.idNumber.test(idNumber)) {
      return res.status(400).json({ error: 'Invalid input format' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Save customer to database
    const newCustomer = new Customer({
      firstName,
      lastName,
      emailAddress,
      username,
      password: hashedPassword,
      accountNumber,
      idNumber
    });
    await newCustomer.save();

    res.status(201).json({ message: 'Customer registered successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Registration failed' });
  }
});

module.exports = router;
