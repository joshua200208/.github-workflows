const express = require('express');
const mongoose = require('mongoose');
const helmet = require('helmet');
const fs = require('fs');
const https = require('https');
const CustomerController = require('./customer.controller');
const app = express();

// Middleware for security
app.use(helmet());
app.use(express.json());

// MongoDB connection
mongoose.connect(
  'mongodb+srv://Aministrator1:<6ch8lwra8W94nTNi>@desired.kjpimqe.mongodb.net/customer_login',
  { useNewUrlParser: true, useUnifiedTopology: true }
);

// SSL setup
const options = {
  cert: fs.readFileSync('./keys/certificate.pem'),
  key: fs.readFileSync('./keys/privatekey.pem')
};

// Routes
app.use('/register', CustomerController);

// Start the server with HTTPS
https.createServer(options, app).listen(3000, () => {
  console.log('Server is running securely on port 3000');
});
