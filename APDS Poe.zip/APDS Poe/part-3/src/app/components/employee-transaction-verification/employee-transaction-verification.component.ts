import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup ,Validators} from '@angular/forms';


@Component({
  selector: 'app-payment-verification',
  templateUrl: './employee-transaction-verification.component.html',
  styleUrls: ['./employee-transaction-verification.component.css']
})
export class PaymentVerificationComponent implements OnInit {
  
  verificationForm: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.verificationForm = this.fb.group({
      recipientName: ['', Validators.required],
      recipientBank: ['', Validators.required],
      accountNo: ['', Validators.required],
      amount: ['', [Validators.required, Validators.min(1)]],
      swiftCode: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.verificationForm.valid) {
      const formData = this.verificationForm.value;
      this.http.post('http://localhost:3000/verify', formData).subscribe(
        (response) => console.log('Submission successful', response),
        (error) => console.error('Error submitting form', error)
      );
    }
  }

  onReject(): void {
    this.verificationForm.reset();
  }
}
