import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeTransactionVerificationComponent } from './employee-transaction-verification.component';

describe('EmployeeTransactionVerificationComponent', () => {
  let component: EmployeeTransactionVerificationComponent;
  let fixture: ComponentFixture<EmployeeTransactionVerificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmployeeTransactionVerificationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeeTransactionVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
