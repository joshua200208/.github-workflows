const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const helmet = require('helmet');
const https = require('https');
const fs = require('fs');
const ExpressBrute = require('express-brute');

// SSL certificates
const privateKey = fs.readFileSync('./keys.privatekey.pem', 'utf8');
const certificate = fs.readFileSync('./keys.certificate.pem', 'utf8');
const credentials = { key: privateKey, cert: certificate };

const app = express();

// Apply Helmet for securing HTTP headers
app.use(helmet());

// Use body-parser to parse incoming JSON data
app.use(bodyParser.json());

// Setup express-brute to prevent brute-force attacks
const store = new ExpressBrute.MemoryStore();
const bruteforce = new ExpressBrute(store);

// Connect to MongoDB
mongoose.connect(
  'mongodb+srv://Aministrator1<6ch8lwra8W94nTNi>@desired.kjpimqe.mongodb.net/employee',
  { useNewUrlParser: true, useUnifiedTopology: true }
).then(() => console.log("Connected to MongoDB"))
 .catch((error) => console.error("MongoDB connection error:", error));

// Define Mongoose schema and model
const verificationSchema = new mongoose.Schema({
  recipientName: String,
  recipientBank: String,
  accountNo: String,
  amount: Number,
  swiftCode: String,
});
const Verification = mongoose.model('Verification', verificationSchema);

// POST endpoint to handle form submission
app.post('/verify', bruteforce.prevent, async (req, res) => {
  try {
    const verificationData = new Verification(req.body);
    await verificationData.save();
    res.status(200).send({ message: 'Data saved successfully!' });
  } catch (error) {
    res.status(500).send({ message: 'Error saving data', error });
  }
});

// Create HTTPS server
const httpsServer = https.createServer(credentials, app);

// Start the server
httpsServer.listen(3000, () => {
  console.log('HTTPS Server running on port 3000');
});
