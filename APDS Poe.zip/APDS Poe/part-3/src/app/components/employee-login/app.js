// Import dependencies
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const helmet = require('helmet');
const fs = require('fs');
const https = require('https');
const { expressBrute } = require('express-brute'); 

// Setup HTTPS with SSL certificates
const privateKey = fs.readFileSync('./keys/privatekey.pem', 'utf8');
const certificate = fs.readFileSync('./keys/certificate.pem', 'utf8');
const credentials = { key: privateKey, cert: certificate };

const app = express();
app.use(helmet()); // Security headers
app.use(express.json());

const mongoUri = 'mongodb+srv://Aministrator1:<6ch8lwra8W94nTNi>@desired.kjpimqe.mongodb.net/employee';
mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true });

// Employee schema and model
const employeeSchema = new mongoose.Schema({
  username: String,
  password: String,
});
const Employee = mongoose.model('hardcodedDetails', employeeSchema);

// Brute force protection
const bruteForce = new expressBrute();

app.post('/login', bruteForce.prevent, async (req, res) => {
  try {
    const { username, password } = req.body;
    const employee = await Employee.findOne({ username });
    if (employee && await bcrypt.compare(password, employee.password)) {
      res.status(200).json({ message: 'Login successful' });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// HTTPS server setup
const httpsServer = https.createServer(credentials, app);
httpsServer.listen(3000, () => {
  console.log('HTTPS Server running on port 3000');
});

const privateKey = fs.readFileSync('./keys/privatekey.pem', 'utf8');
const certificate = fs.readFileSync('./keys/certificate.pem', 'utf8');
const credentials = { key: privateKey, cert: certificate };

const app = express();
app.use(helmet()); // Security headers
app.use(express.json());

const mongoUri = 'mongodb+srv://Aministrator1:<6ch8lwra8W94nTNi>@desired.kjpimqe.mongodb.net/employee';
mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true });

// Employee schema and model
const employeeSchema = new mongoose.Schema({
  username: String,
  password: String,
});
const Employee = mongoose.model('hardcodedDetails', employeeSchema);

// Brute force protection
const store = new ExpressBrute.MemoryStore();
const bruteForce = new ExpressBrute(store);

app.post('/login', bruteForce.prevent, async (req, res) => {
  try {
    const { username, password } = req.body;
    const employee = await Employee.findOne({ username });
    if (employee && await bcrypt.compare(password, employee.password)) {
      res.status(200).json({ message: 'Login successful' });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// HTTPS server setup with SSL certificates
const httpsServer = https.createServer(credentials, app);
httpsServer.listen(3000, () => {
  console.log('Secure HTTPS Server running on port 3000');
});