import { Component } from '@angular/core';
import { AuthService } from './auth/service';  
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-employee-login',
  standalone: true,
  imports: [],
  templateUrl: './employee-login.component.html',
  styleUrl: './employee-login.component.css'
})
export class EmployeeLoginComponent {

  loginForm: FormGroup;

  constructor(private authService: AuthService, private fb: FormBuilder,private router: Router) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  login() {
    if (this.loginForm.valid) {
      const { username, password } = this.loginForm.value;
      this.authService.login(username, password).subscribe({
        next: response => {
          alert(response.message);
          // Redirect to employee-transaction-verification on successful login
          this.router.navigate(['/employee-transaction-verification']);
        },
        error: () => alert('Login failed')
      });
    }
  }
}
