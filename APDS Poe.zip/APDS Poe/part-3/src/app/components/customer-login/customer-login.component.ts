import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-customer-login',
  standalone: true,
  imports: [],
  templateUrl: './customer-login.component.html',
  styleUrl: './customer-login.component.css'
})
export class CustomerLoginComponent {
  username: string = '';
  accountNumber: string = '';
  password: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
    this.authService.login(this.username, this.accountNumber, this.password).subscribe({
      next: (response) => {
        alert('Login successful');
        this.router.navigate(['/customer-dashboard']);
      },
      error: (error) => {
        alert('Invalid login credentials');
      }
    });
  }
  
}
