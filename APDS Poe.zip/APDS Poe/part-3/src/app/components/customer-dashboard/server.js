const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

// MongoDB Connection
mongoose.connect('mongodb+srv://Aministrator1:<password>@desired.kjpimqe.mongodb.net/banking', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.error('MongoDB connection error:', err));

const app = express();
app.use(cors());
app.use(express.json());

// Define a banking schema and model
const bankingSchema = new mongoose.Schema({
  customerName: String,
  accNo: String,
  availableBalance: Number,
});

const BankingDetails = mongoose.model('BankingDetails', bankingSchema);

// Endpoint to fetch banking details
app.get('/api/banking-details', async (req, res) => {
  try {
    // Fetch banking details from the MongoDB collection
    const bankingDetails = await BankingDetails.findOne(); // You can filter by customer ID if necessary
    res.json(bankingDetails);
  } catch (error) {
    res.status(500).send('Error fetching banking details');
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
