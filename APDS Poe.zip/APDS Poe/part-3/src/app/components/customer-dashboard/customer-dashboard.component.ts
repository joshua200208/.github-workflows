import { Component,OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-customer-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './customer-dashboard.component.html',
  styleUrl: './customer-dashboard.component.css'
})
export class CustomerDashboardComponent {
  
  userName: string = '';  // Will hold the logged-in customer name
  bankingDetails: any = {};  // To hold banking information
  private apiUrl = 'https://your-backend-api.com/api/banking-details';  // URL to the backend API

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    // Assuming user data (like customer name) is stored in localStorage or sessionStorage
    this.userName = sessionStorage.getItem('userName') || 'Customer';

    // Fetch the banking details from MongoDB via the backend
    this.fetchBankingDetails();
  }

  // Fetching the banking details from the backend
  fetchBankingDetails(): void {
    this.http.get<any>(this.apiUrl).subscribe(
      (data) => {
        this.bankingDetails = data;
      },
      (error) => {
        console.error('Error fetching banking details', error);
      }
    );
  }

  // Navigate to the customer-payment-process component
  goToPaymentProcess(): void {
    this.router.navigate(['/customer-payment-process']);
  }

}
