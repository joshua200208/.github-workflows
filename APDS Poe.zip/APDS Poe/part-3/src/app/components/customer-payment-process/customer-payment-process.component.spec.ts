import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerPaymentProcessComponent } from './customer-payment-process.component';

describe('CustomerPaymentProcessComponent', () => {
  let component: CustomerPaymentProcessComponent;
  let fixture: ComponentFixture<CustomerPaymentProcessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CustomerPaymentProcessComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerPaymentProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
