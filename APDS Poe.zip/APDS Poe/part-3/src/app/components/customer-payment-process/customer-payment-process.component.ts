import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-payment-process',
  standalone: true,
  imports: [],
  templateUrl: './customer-payment-process.component.html',
  styleUrl: './customer-payment-process.component.css'
})
export class CustomerPaymentProcessComponent {

  paymentForm: FormGroup;

  constructor(private fb: FormBuilder, private http: HttpClient, private router: Router) {
    this.paymentForm = this.fb.group({
      recipientName: [''],
      recipientBank: [''],
      accountNumber: [''],
      amount: [''],
      swiftCode: ['']
    });
  }

  onSubmit() {
    this.http.post('/api/payment', this.paymentForm.value).subscribe(
      () => {
        alert('Payment Submitted Successfully');
        this.router.navigate(['/customer-dashboard']);
      },
      (error) => {
        console.error('Error submitting payment', error);
      }
    );
  }

}
