// server.js

const express = require('express');
const mongoose = require('mongoose');
const helmet = require('helmet');
const fs = require('fs');
const bcrypt = require('bcrypt');
const https = require('https');
const BruteForce = require('express-brute');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
require('dotenv').config();

const app = express();

// Apply Helmet for securing headers
app.use(helmet());

// Configure brute force protection
const store = new BruteForce.MemoryStore();
const bruteForce = new BruteForce(store);

// SSL options
const sslOptions = {
  cert: fs.readFileSync('./keys.certificate.pem'),
  key: fs.readFileSync('./keys.privatekey.pem')
};

// Connect to MongoDB
mongoose.connect(
  'mongodb+srv://Aministrator1:<6ch8lwra8W94nTNi>@desired.kjpimqe.mongodb.net/banking',
  { useNewUrlParser: true, useUnifiedTopology: true, ssl: true }
);

app.use(bodyParser.json());

// Define payment schema and model
const paymentSchema = new mongoose.Schema({
  recipientName: String,
  recipientBank: String,
  accountNumber: String,
  amount: Number,
  swiftCode: String,
  userId: String  // Token-based pairing field
});
const Payment = mongoose.model('details', paymentSchema);

// Middleware to authenticate using a token
function authenticateToken(req, res, next) {
  const token = req.headers['authorization'];
  if (!token) return res.sendStatus(403);

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

// Secure endpoint to handle payment submissions
app.post('/api/payment', bruteForce.prevent, authenticateToken, async (req, res) => {
  try {
    const { recipientName, recipientBank, accountNumber, amount, swiftCode } = req.body;
    const userId = req.user.id;  // Retrieve user ID from token

    const payment = new Payment({ recipientName, recipientBank, accountNumber, amount, swiftCode, userId });
    await payment.save();

    res.status(200).json({ message: 'Payment saved successfully.' });
  } catch (error) {
    res.status(500).json({ message: 'Error saving payment data.', error });
  }
});

// Start HTTPS server
https.createServer(sslOptions, app).listen(3000, () => {
  console.log('Secure server running on port 3000');
});
