import { RouterModule, Routes } from '@angular/router';
import { EmployeeLoginComponent } from './components/employee-login/employee-login.component';
import { PaymentVerificationComponent } from './components/employee-transaction-verification/employee-transaction-verification.component';
import { RegisterComponent } from './components/customer-register/customer-register.component';
import { AppComponent } from './app.component';
import { CustomerLoginComponent } from './components/customer-login/customer-login.component';
import { CustomerDashboardComponent } from './components/customer-dashboard/customer-dashboard.component';
import { CustomerPaymentProcessComponent } from './components/customer-payment-process/customer-payment-process.component';
import { NgModule } from '@angular/core';


export const routes: Routes = [
    {
        path: '',title: 'App Home Page',component: AppComponent,},
      {
        path: 'employee-login-component',title: 'employee login',component: EmployeeLoginComponent,},
      {
        path: 'customer-login-component',title: 'customer login',component: CustomerLoginComponent,},
      {
        path: 'customer-register-component',title: 'customer register',component: RegisterComponent,},
      {
        path: 'employee-login-component',title: 'verify payment', component: PaymentVerificationComponent, },
      {
        path: 'customer-login-component',title: 'customer dashboard', component: CustomerDashboardComponent, },
      {
        path: 'customer-register-component', title: 'customer payment process',component: CustomerPaymentProcessComponent, },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}


